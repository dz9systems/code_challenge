CREATE DATABASE = userPosts;

CREATE TABLE User(
    
    User_id  serial PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_on TIMESTAMP NOT NULL,
    last_login TIMESTAMP

)


CREATE TABLE userPosts(
    
    userPosts_id  INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    title VARCHAR(60) NOT NULL,
    img_url TEXT NOT NULL,
    description VARCHAR(100) NOT NULL,
    created_on TIMESTAMP NOT NULL,


)