const express = require('express');
const app = express();
const cors = require('cors');
const pool = require('./db');
const bodyParser = require('body-parser');


//MIDDLEWARE
app.use(cors());
app.use(express.json());
// parse application/json
app.use(bodyParser.json());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended:true }) );


//ROUTES


//CREATE A USER
app.post("/createUser", async (req,res) => {
 try{
   console.log(req.body);
//    res.json(req.body);
   res.sendStatus(200)

 }
 catch(err){
    console.log(err.message);
    res.end();
 }
})

//GET ALL USERS




//CREATE A USER POST


//CREATE ALL USER POST


//UPDATE A POST


app.listen(5000, () => {
    console.log('server has started on port 5000')
}) 